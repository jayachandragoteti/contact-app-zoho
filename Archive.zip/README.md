# contact-app-zoho

Installation Process

To run the web application we need install a Server (xampp,wampp,etc..)
Xampp download link: https://www.apachefriends.org/download.html

Step 1: Install Xampp
Step 2: Movie the file to xampp/htdocs
Step 3: Start the Apache and Mysql
Step 4: Open the Php MyAdmin ( http://localhost/phpmyadmin/)
Step 5: Create a database with name "contact-app-zoho"
Step 6: Import the database tables into "contact-app-zoho" database from sql file 'contact-app-zoho.sql'
Step 7: open 'http://localhost/contact-app-zoho/index.php' in any browser
